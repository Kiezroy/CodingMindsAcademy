package codingMinds;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class HoroscopeGenerator {

	public static void main(String[] args) {
		pickHoroscope(genHoroscope(userQuiz()));
	}
	
	
	public static String userQuiz() {
		Scanner scan = new Scanner(System.in);
		String sign = "";
		String month;
		int day;
		
		System.out.println("Enter in your birth month: ");
		month = scan.next().toLowerCase();
		
		System.out.println("Enter in your birthday");
		day = scan.nextInt();
		
		if((month.equals("march") && day >= 21) || (month.equals("april") && day <= 19)) {
			sign = "Aries";
		}
		else if((month.equals("april") && day >= 20) || (month.equals("may") && day <= 20)) {
			sign = "Taurus";
		}
		else if((month.equals("may") && day >= 21) || (month.equals("june") && day <= 20)) {
			sign = "Gemini";
		}
		else if((month.equals("june") && day >= 21) || (month.equals("july") && day <= 22)) {
			sign = "Cancer";
		}
		else if((month.equals("july") && day >= 23) || (month.equals("august") && day <= 22)) {
			sign = "Leo";
		}
		else if((month.equals("august") && day >= 23) || (month.equals("september") && day <= 22)) {
			sign = "Virgo";
		}
		else if((month.equals("september") && day >= 23) || (month.equals("october") && day <= 22)) {
			sign = "Libra";
		}
		else if((month.equals("october") && day >= 23) || (month.equals("november") && day <= 21)) {
			sign = "Scorpio";
		}
		else if((month.equals("november") && day >= 22) || (month.equals("december") && day <= 21)) {
			sign = "Sagittarius";
		}
		else if((month.equals("december") && day >= 22) || (month.equals("january") && day <= 19)) {
			sign = "Capricorn";
		}
		else if((month.equals("january") && day >= 20) || (month.equals("february") && day <= 18)){
			sign = "Aquarius";
		}
		else {
			sign = "Pisces";
		}
    
		return sign;
	}
	
	public static ArrayList<String> genHoroscope(String sign) {
        // The name of the file to open.
        String fileName = sign + ".txt";
        ArrayList<String> horoscopes = new ArrayList<String>();
        
        
        // This will reference one line at a time
        String line = null;

        try {
            // FileReader reads text files in the default encoding.
            FileReader fileReader = new FileReader(fileName);

            // Always wrap FileReader in BufferedReader.
            BufferedReader bufferedReader = new BufferedReader(fileReader);

            while((line = bufferedReader.readLine()) != null) {
            	//reads from file and adds into the array
                horoscopes.add(line);
            }   

            // Always close files.
            bufferedReader.close();         
        }
        catch(FileNotFoundException ex) {
            System.out.println("Unable to open file '" + fileName + "'");                
        }
        catch(IOException ex) { 
            System.out.println("Error reading file '" + fileName + "'");                  
            // Or we could just do this: 
            // ex.printStackTrace();
        }
		
		return horoscopes;
		
	}
	
	//Method picks out a random horoscope from each file
	public static void pickHoroscope(ArrayList<String> horoscopes) {
		Random rand = new Random();
		int n = rand.nextInt(horoscopes.size());
		System.out.println(horoscopes.get(n));
	}
}
